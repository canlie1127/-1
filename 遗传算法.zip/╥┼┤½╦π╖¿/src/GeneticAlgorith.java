import java.util.*;
public class GeneticAlgorith {
    public List<Chromosome> population=new ArrayList<Chromosome>();//������е���Ⱥ����
    private int popSize; //��Ⱥ��ģN
    private int chromoLength;//ÿ��Ⱦɫ����Ŀm��
    private double mutationRate=0.01;//����ͻ�����pm
    private  double crossoverRate=0.6;//�������pc
    private int bagMax=1000;

    private int generation;//��Ⱥ����t
    private int iterNum=10000;//����������
   // private int stepmax=3;//�����

    private int [] charge={220,208,198,192,180,180,165,162,160,158,155,130,125,122,120,118,115,110,105,101,100,100,98,96,95,90,88,82,80,77,75,73,72,70,69,66,65,63,60,58,56,50,30,20,15,10,8,5,3,1};
    private int [] weight={80,82,85,70,72,70,66,50,55,25,50,55,40,48,50,32,22,60,30,32,40,38,35,32,25,28,30,22,50,30,45,30,60,50,20,65,20,25,30,10,20,25,15,10,10,10,4,4,2,1};
    private double[]  density=new double[50];

    private Chromosome nowGenome;
    private Chromosome bestFit; //�����Ӧ�ȶ�Ӧ��Ⱦɫ��
    private Chromosome iterBestFit;//ȫ������Ⱦɫ��
    private double bestFitness;//��Ⱥ�����Ӧ��
    private double worstFitness;//��Ⱥ���Ӧ��
    private double averageFitness;


    private double x1;
    private double x2;
    private double y=0;

    public Chromosome getNowGenome() {
        return nowGenome;
    }


    public void setNowGenome(Chromosome nowGenome) {
        this.nowGenome = nowGenome;
    }

    public Chromosome getIterBestFit() {
        return iterBestFit;
    }

    public void setIterBestFit(Chromosome iterBestFit) {
        this.iterBestFit = iterBestFit;
    }

    public Chromosome getBestFit() {
        return bestFit;
    }

    public void setBestFit(Chromosome bestFit) {
        this.bestFit = bestFit;
    }

    public double getBestFitness() {
        return bestFitness;
    }

    public void setBestFitness(double bestFitness) {
        this.bestFitness = bestFitness;
    }

    public double getWorstFitness() {
        return worstFitness;
    }

    public void setWorstFitness(double worstFitness) {
        this.worstFitness = worstFitness;
    }

    public double getTotalFitness() {
        return totalFitness;
    }

    public void setTotalFitness(double totalFitness) {
        this.totalFitness = totalFitness;
    }

    private double totalFitness;//��Ⱥ����Ӧ��
    private Random random=new Random();

    public int sumCharge(){
        int sumone=0;
        for(int i=0;i<charge.length;i++){
            sumone+=charge[i];

        }
        return sumone;
    }
    public int sumWeight(){
        int sumtwo=0;
        for(int i=0;i<weight.length;i++){
            sumtwo+=weight[i];

        }
        return sumtwo;
    }


    //����Getting����

    public GeneticAlgorith(int popSize){
        this.popSize=popSize;

    }
    /*
    ��ʼ����Ⱥ
     */
    public void init(){
        for(int i=0;i<charge.length;i++){
            density[i]=charge[i]/weight[i];
        }

        for(int i=0;i<popSize;i++){
            Chromosome g=new Chromosome(50);
            changeGene(g);
            population.add(g);
        }
        caculteFitness();


    }
    /*
    ������Ⱥ��Ӧ��
     */
    public void caculteFitness(){

        bestFitness=population.get(0).getFitness();
        worstFitness=population.get(0).getFitness();
        totalFitness=0;
        for (Chromosome g:population) {
            //changeGene(g);
            setNowGenome(g);
            if(g.getFitness()>bestFitness){
                setBestFitness(g.getFitness());
                if(y<bestFitness){
                    y=g.getFitness();
                }
                setIterBestFit(g);

            }
            if(g.getFitness()<worstFitness){
                worstFitness=g.getFitness();
            }
            totalFitness+=g.getFitness();

        }
        averageFitness = totalFitness / popSize;
        //��Ϊ�������⵼�µ�ƽ��ֵ�������ֵ����ƽ��ֵ���ó����ֵ
        averageFitness = averageFitness > bestFitness ? bestFitness : averageFitness;


    }

    /*
    ���̶�ѡ���㷨
     */
    public Chromosome getChromoRoulette(){
        double db=random.nextDouble();
        double randomFitness=db*totalFitness;
        Chromosome choseOne=null;
        double sum=0.0;
        for(int i=0;i<population.size();i++){
            choseOne=population.get(i);
            sum+=choseOne.getFitness();
            if(sum>=randomFitness){
                break;
            }
        }
        return choseOne;

    }


    /*
    clone
    */
    public static Chromosome clone(Chromosome c){
        if (c==null||c.gene==null){
            return null;
        }
        Chromosome copy=new Chromosome();
        copy.initSize(50);
        for (int i=0;i<c.gene.length;i++){
            copy.gene[i]=c.gene[i];
        }
        copy.setFitness(c.getFitness());
        return copy;

    }

    /*
    ���㽻��
     */
    public static List<Chromosome> genetic(Chromosome p1,Chromosome p2){
        if(p1==null||p2==null){
            return null;
        }
        if(p1.gene==null||p2.gene==null){
            return null;
        }
        if(p1.gene.length!=p2.gene.length){
            return null;
        }
        Chromosome c1=clone(p1);
        Chromosome c2=clone(p2);
        int size=c1.gene.length;
        int a=(int)(Math.random()*size)%size;
        int b=(int)(Math.random()*size)%size;
        int min=a>b?b:a;
        int max=a>b?a:b;
        if(max-min>15){
            max=min+15;
        }//��󲽳�Ϊ10

        for(int i=min;i<max;i++){
            boolean temp=c1.gene[i];
            c1.gene[i]=c2.gene[i];
            c2.gene[i]=temp;
        }

        c1.setFitness(c1.getFitness());
        c2.setFitness(c2.getFitness());

        List<Chromosome> listNew=new ArrayList<Chromosome>();
        listNew.add(c1);
        listNew.add(c2);
        return listNew;
    }
    /*
    ̰�ı任����
     */
    public void changeGene(Chromosome c){
        int flag=0;
        int fitnessNow=0;
        int weightNow=0;
        Map<Integer,Double> map=new TreeMap<Integer, Double>();
        for(int i=0;i<c.gene.length;i++){
            if(c.gene[i]==true){
                map.put(i,density[i]);
            }
        }
        Comparator<Map.Entry<Integer, Double>> valueComparator = new Comparator<Map.Entry<Integer, Double>>() {
            @Override
            public int compare(Map.Entry<Integer, Double> o1, Map.Entry<Integer, Double> o2) {
                return o2.getValue().compareTo(o1.getValue());
            }
        };
        List<Map.Entry<Integer,Double>> list=new ArrayList<Map.Entry<Integer, Double>>(map.entrySet());
        Collections.sort(list,valueComparator);
        for (Map.Entry<Integer,Double> entry:list) {

            if(weightNow+weight[entry.getKey()]<=bagMax){
            //if(flag==0){
                fitnessNow+=charge[entry.getKey()];
                weightNow+=weight[entry.getKey()];
            }
            else{
                //flag=1;
                c.gene[entry.getKey()]=false;
            }

            /*
            fitnessNow+=charge[entry.getKey()];
            weightNow+=weight[entry.getKey()];
            if(weightNow<=bagMax){
                c.setFitness(fitnessNow);
            }
            else{
                c.setFitness(0);
            }
            */
            c.setFitness(fitnessNow);
            
        }
    }
    /*
    �����㷨
     */
    public void evolve() {
        List<Chromosome> childrenGenome = new ArrayList<Chromosome>();

        for (int j = 0; j < popSize / 2; j++) {
            Chromosome g1 = getChromoRoulette();
            Chromosome g2 = getChromoRoulette();
            double r = random.nextDouble();

            if (r <= crossoverRate) {
                List<Chromosome> children = genetic(g1, g2);
                if (children != null) {
                    for (Chromosome g : children) {
                        changeGene(g);
                        childrenGenome.add(g);
                        g.mutation(50, mutationRate);
                        changeGene(g);
                        childrenGenome.add(g);
                    }
                }

            }
            childrenGenome.add(g1);
            childrenGenome.add(g2);
        }
        List<Chromosome> temGen = new ArrayList<Chromosome>();
        population.clear();

        for (int i = 0; i < popSize*0.2; i++) {
            int max = 0;

            for (Chromosome tempG : childrenGenome) {
                if (tempG.getFitness() > max) {
                    max = tempG.getFitness();
                    setBestFit(tempG);
                }

            }
            temGen.add(getBestFit());
            childrenGenome.remove(getBestFit());
            setBestFit(null);

        }
        population = childrenGenome;
        caculteFitness();

        while (temGen.size() < popSize) {
            Chromosome tp1 = getChromoRoulette();
            temGen.add(tp1);
        }

        /*
        while (temGen.size()<popSize){
            Chromosome tp1=new Chromosome(50);
            temGen.add(tp1);
        }
        */

        population = temGen;


        //���¼�����Ⱥ��Ӧ��
        caculteFitness();
    }
    /*
    �Ŵ��㷨GA����
     */
    public void geneticAlgorithProcess(){
        generation=1;
        init();
        while(generation<iterNum){
            evolve();
            print();
            generation++;
        }
    }
    public void print(){
        System.out.println("this is generation "+generation);
        System.out.println("the best fitness is "+y);
        System.out.println("-----------------------------------------------");
        if(generation==iterNum-1){
            for(int i=0;i<50;i++){
                if(iterBestFit.gene[i]==true){
                    System.out.printf("1");
                }
                else{
                    System.out.printf("0");
                }
                System.out.printf(" ");
            }
            System.out.println("");
        }
    }
}