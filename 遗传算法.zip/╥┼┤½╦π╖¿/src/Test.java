public class Test {
    public static void main(String[] args) {
        GeneticAlgorith g=new GeneticAlgorith(100);
        g.geneticAlgorithProcess();
        System.out.println(g.sumCharge());
        System.out.println(g.sumWeight());
        g=null;
    }
}
